package aula02.exemplo.exercicios;

public class exercicio01 {
    public static void main(String[] args) {
        int idade;
        float altura;
        double peso;

        idade = 17;
        altura = 1.65f;
        peso = 57.60;

        System.out.println("Sua idade é " + idade + " e voce tem "
                + altura + " metros " + " e tem " + peso + " kg ");
    }
}
