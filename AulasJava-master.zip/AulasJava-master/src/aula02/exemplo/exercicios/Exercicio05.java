package aula02.exemplo.exercicios;

public class Exercicio05 {

    public static void main(String[] args) {
        int nota1 = 8;
        int nota2 = 5;
        int nota3 = 2;
        int soma = nota1 + nota2 + nota3;

        System.out.print(soma);
    }
}
