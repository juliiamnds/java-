package aula02.exemplo.exercicios;

public class Exercicio06 {

    public static void main(String[] args) {
        int num1 = 7;
        int num2 = 5;
        boolean numResultado;

        numResultado = num1 > num2;
        System.out.println(numResultado);

        numResultado = num1 < num2;
        System.out.println(numResultado);

        numResultado = num1 >= num2;
        System.out.println(numResultado);

        numResultado = num1 <= num2;
        System.out.println(numResultado);

        numResultado = num1 == num2;
        System.out.println(numResultado);

        numResultado = num1 != num2;
        System.out.println(numResultado);
    }
}
