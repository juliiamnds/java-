package aula02.exemplo.exercicios;

public class Exercicio03 {
    public static void main(String[] args) {

        int numInt = 264;
        double numDouble = numInt;

        System.out.println("O número de double é: "+ numDouble);

        }
}
