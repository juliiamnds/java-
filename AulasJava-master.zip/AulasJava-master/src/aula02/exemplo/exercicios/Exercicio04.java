package aula02.exemplo.exercicios;

public class Exercicio04 {
    public static void main(String[] args) {
        double numDouble = 24.99;
        int numInt = (int) numDouble;

        System.out.println("O número double em inteiro é: " + numInt);

    }
}

