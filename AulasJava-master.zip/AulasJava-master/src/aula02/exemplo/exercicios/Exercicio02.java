package aula02.exemplo.exercicios;

public class Exercicio02 {
    public static void main(String[] args) {
        int horas = 6;
        int valor_pago = 140;
        int valor_total = horas * valor_pago;
        System.out.println(" Valor total por hora: " +valor_total);

    }
}
