package aula02.exemplo;

public class Exemplos {
    public static void main(String[] args) {
        System.out.printf("Olá Mundo");

    }

}