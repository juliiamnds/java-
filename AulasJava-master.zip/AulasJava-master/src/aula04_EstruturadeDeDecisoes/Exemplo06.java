package aula04_EstruturadeDeDecisoes;

public class Exemplo06 {
    public static void main(String[] args) {
        int x= 40;
        boolean r;

        r = x>50 ? true : false;
        System.out.println(r);
    }
}
